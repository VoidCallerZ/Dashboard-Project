import paramiko
import os
import zipfile
import platform
import subprocess
import sys

#Get current working directory based on the operating system
cwd = os.getcwd()
cwd += "\\" if platform.system() == "Windows" else "/"

#Function for downloading a set file over SSH
def download_file(host, username, password, remote_path, local_path):
    #Set up the SSH session using Paramiko
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    #Try connecting with SSH
    #On success: Set up and SFTP connection for file transfer and download the set file
    #On failure: Print exception to the console
    try:
        ssh.connect(hostname=host, port=22, username=username, password=password)
        sftp = ssh.open_sftp()
        sftp.get(remote_path, local_path)
        print(f"File downloaded successfully from {remote_path} to {local_path}")
        return True
    
    except Exception as e:
        print(f"Error: {e}")
        return False
    finally:
        #Close the SSH and SFTP connection
        if 'sftp' in locals():
            sftp.close()
        ssh.close()

#Function for the actual update of the program
def update_program(hostname, username, password, remote_path):
    #Set the correct paths for the update to go to
    extract_path = cwd
    zip_path = cwd + "Dashboard.zip"
    latest_path = "latest_version.txt"

    #Try downloading the Dashboard.zip file via SSH/SFTP
    #On success: Extract the downloaded zip file to the current working directory
    os_zip = "Dashboard_Windows.zip" if platform.system() == "Windows" else "Dashboard.zip"
    if download_file(hostname, username, password, remote_path + os_zip, zip_path):
        with zipfile.ZipFile(zip_path) as zip_ref:
            zip_ref.extractall(extract_path)

        print("Update installed successfully. Updating version history!")

        #Try downloading the version.txt file via SSH/FTP
        #On success: Detect difference in latest version vs current version
        #Overwrite the current version with the latest version
        if download_file(hostname, username, password, remote_path + "version.txt", latest_path):
            with open(latest_path, "r") as latest:
                latest_version = latest.read()
                with open("version.txt", "r") as current:
                    current_version = current.read()
                
                if current_version != latest_version:
                    with open("version.txt", "w") as f:
                        f.write(latest_version)
                        f.flush()
                        print("Restarting dashboard script!")
                        #Restart the Dashboard.py script
                        subprocess.Popen("Dashboard.exe") if platform.system() == "Windows" else subprocess.Popen(["python3", "Dashboard.py"])
                else:
                    print("Current version is up to date.")
        else:
            print("Download version.txt failed...")
    else:
        print("Downloading update failed...")


host = '192.168.0.123'
username = 'ssh'
password = '3QjH4JeIT0JEepPi'
remote_path = 'C:\\Users\\ssh\\Documents\\'

update_program(host, username, password, remote_path)
