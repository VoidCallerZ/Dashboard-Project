import requests
import zipfile
import subprocess
import platform
import os

current_working_directory = os.getcwd()
current_working_directory += "\\" if platform.system() == "Windows" else "/"

def update_program():
    file_path = current_working_directory
    response = requests.get("https://github.com/VoidCallerZ/Dashboard-Project/raw/main/Dashboard.zip")

    if response.status_code == 200:
        with open(file_path, 'wb') as f:
            f.write(response.content)
        with zipfile.ZipFile(file_path) as zip_ref:
            zip_ref.extractall(file_path)
        print("Update installed successfully. Restart dashboard script!")
        subprocess.call(["python", "Dashboard.py"]) if platform.system() == "Windows" else subprocess.call(["python3", "Dashboard.py"])
    else:
        print("Downloading update failed.")

update_program()