import requests
import zipfile
import subprocess
import platform
import os

current_working_directory = os.getcwd()
current_working_directory += "\\" if platform.system() == "Windows" else "/"

def update_program():
    extract_path = current_working_directory
    zip_path = current_working_directory + "Dashboard.zip"
    response = requests.get("https://github.com/VoidCallerZ/Dashboard-Project/raw/main/Dashboard.zip")

    if response.status_code == 200:
        with open(zip_path, 'wb') as f:
            f.write(response.content)
        with zipfile.ZipFile(zip_path) as zip_ref:
            zip_ref.extractall(extract_path)
        print("Update installed succesfully. Updating version history!")
        update_version_history()
    else:
        print("Downloading update failed.")

def update_version_history():
    response = requests.get("https://github.com/VoidCallerZ/Dashboard-Project/raw/main/version.txt")
    latest_version = response.text.strip()

    with open("version.txt", 'r') as f:
        current_version = f.read()
    
    if current_version < latest_version:
        with open("version.txt", 'w') as f:
            f.write(latest_version)
        print("Restarting dashboard script!")
        subprocess.call(["python", "Dashboard.py"]) if platform.system() == "Windows" else subprocess.call(["python3", "Dashboard.py"])
    else:
        print("Current version is up to date.")

update_program()