#!/bin/bash

gnome-terminal -- /usr/bin/python3 UpdateDashboardScript.py
