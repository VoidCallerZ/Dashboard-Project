#!/bin/bash

cd ~/Documents
gnome-terminal -- /usr/bin/python3 Dashboard.py