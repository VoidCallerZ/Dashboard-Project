#!/bin/bash
cd /home/rick/Documents
gnome-terminal -- /usr/bin/python3 Dashboard.py